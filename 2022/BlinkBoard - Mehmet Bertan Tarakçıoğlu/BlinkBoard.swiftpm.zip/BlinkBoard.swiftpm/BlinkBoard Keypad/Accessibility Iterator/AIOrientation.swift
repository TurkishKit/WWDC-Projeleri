//
//  AIOrientation.swift
//  
//
//  Created with love and passion by Bertan
//
// Enum type type that specifies if the accessibility iterator is horizontally or vertically stacked

enum AIOrientation {
    case horizontal, vertical
}
