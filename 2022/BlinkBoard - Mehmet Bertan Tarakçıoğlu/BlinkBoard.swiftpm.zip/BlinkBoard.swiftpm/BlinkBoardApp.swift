//
//  BlinkBoard_XCApp.swift
//
//
//  Created with love and passion by Bertan
//
// Default standart SwiftUI lifecycle file, nothing too fancy here :)

import SwiftUI

@main
struct BlinkBoardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
