//
//  VBDError.swift
//
//
//  Created with love and passion by Bertan
//
// Error enum for VisionBlinkDetectorVC

enum VBDError: Error {
    case camPermissionDenied, noCaptureDevices, noInputs, invalidInputs
}
