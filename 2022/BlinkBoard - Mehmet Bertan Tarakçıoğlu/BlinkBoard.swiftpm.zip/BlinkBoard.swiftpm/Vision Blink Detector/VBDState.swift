//
//  VBDState.swift
//
//
//  Created with love and passion by Bertan
//
// Enum with the all possible detections from VisionBlinkDetectorVC

enum VBDState: String {
    case noFaces, eyesOpen, eyesClosed, multipleFaces
}
