/*:
 
 ![Add Questions Image](AddQuestions.png)
 
 # Add Questions to Chatbots

 It's time to add your own questions to chatbots. In this page, you learn how to add your own questions. 😎
 
 * To add a question, use addQuestion function like editing chatbot.

 addQuestion is a function that help us to add questions to chatbots. This function have three parameters: botName, questions and answers. We should write name of chatbot to botName, questions array to questions parameter, and answers array to answers parameter. When you ask a question which inside of myQuestions array, chatbot select an randomize answer inside myAnswers and response with this answer. 💬
 
 To add a question to chatbot, change this code snippet and run code. 👇
*/
//#-hidden-code
setView(page: 2)
//#-end-hidden-code
let myQuestions = /*#-editable-code*/["Where do you live?"]/*#-end-editable-code*/
let myAnswers = /*#-editable-code*/["Turkey. 🇹🇷", "In Turkey. 😁"]/*#-end-editable-code*/

addQuestion(botName: /*#-editable-code*/"ChatBot"/*#-end-editable-code*/, questions: myQuestions, answers: myAnswers)
//#-hidden-code
saveUserInput(input: myQuestions)
//#-end-hidden-code
