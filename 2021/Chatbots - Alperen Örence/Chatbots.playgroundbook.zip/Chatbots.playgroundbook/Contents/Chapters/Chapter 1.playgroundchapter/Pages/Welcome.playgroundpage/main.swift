/*:
 
 ![Introduction Image](Introduction.png)
 
 # Introduction

 
 
 - callout(What is Chatbots?):
 "Chatbots is a software application used to conduct an on-line chat conversation via text or text-to-speech. Chatbots can automate conversations and interact with people through messaging platforms."
 
 Source: [Wikipedia](https://en.wikipedia.org/wiki/Chatbot)  🔍
  

 In this playground, we will learn the basics of chatbots. And also you will create your own chatbot at the end of this playground! 😉
 
 
 Click "Run My Code" and ask a question to chatbot like "Tell me a joke." or "Which technologies announced in WWDC20?". 🤖
 
 After learn how to chat with chatbots, you can go to the [next page](@next). 🥳
*/
//#-hidden-code
setView(page: 0)
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, Page_Contents)
