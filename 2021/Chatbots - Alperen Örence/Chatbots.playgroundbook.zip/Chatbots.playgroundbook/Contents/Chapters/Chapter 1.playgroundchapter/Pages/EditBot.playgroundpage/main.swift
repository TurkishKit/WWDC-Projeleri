/*:
 
 ![Edit Image](Customize.png)
 
 # Customize Chatbots

 After we learn how to chat with chatbots, we can customize chatbots now. In this page, you can change chatbots name or avatar. 🤟
 
 * To change chatbots details (like name and avatar) use editBot function.

 editBot is a function that help us to edit chatbot's details like name and avatar. This function have four parameters: oldName, newName, avatar and avatarColor. We should write name of chatbot to oldName, and new name to newName. If you don't want to change name, write chatbot's name to both parameter. And type an emoji to avatar, which creates chatbot's profile photo. Finally, choose a color that will be the background for the chatbot's profile photo. ✏️

 To edit a chatbot, change this code snippet and run code. 👇
*/
//#-hidden-code
setView(page: 1)
//#-end-hidden-code
editBot(oldName: /*#-editable-code*/"Steve"/*#-end-editable-code*/, newName: /*#-editable-code*/"Tim"/*#-end-editable-code*/, avatarEmoji: /*#-editable-code*/"👨🏼"/*#-end-editable-code*/, avatarColor: /*#-editable-code*/#colorLiteral(red: 0.8274509804, green: 0.3294117647, blue: 0, alpha: 1) /*#-end-editable-code*/)

