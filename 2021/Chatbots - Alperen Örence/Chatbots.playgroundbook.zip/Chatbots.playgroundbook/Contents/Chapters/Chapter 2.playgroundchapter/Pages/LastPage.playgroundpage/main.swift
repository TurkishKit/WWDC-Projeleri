/*:
 
 ![Congratulations Image](Congratulations.png)
 
 # Congratulations 🤩

You finished this playground and you learn how to create a chatbot. 🎉
 
In this page, you can do everything about chatbots. You can create multiple chatbots, and also customize and add questions. 🚀

Be creative. 😉
*/
//#-hidden-code
import PlaygroundSupport
import SwiftUI
import UIKit
import UserModule
setView(page: 5)
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, Page_Contents)
//#-code-completion(identifier, show, addNewBot(name:avatarEmoji:avatarColor:), editBot(oldName:newName:avatarEmoji:avatarColor:), addQuestion(botName:questions:answers:), let, var, func, class, struct)
//#-editable-code

//#-end-editable-code
