/*:
 
 ![Add Questions Image](AddQuestions.png)
 
 # Add Questions to Chatbot

In this page, you can add your questions to your chatbot. 🎉
 
You learned how to add questions to chatbots in third page. Use same function there. 💫
 
Change this code snippet and run code. 👇
 */
//#-hidden-code
setView(page: 4)
//#-end-hidden-code
let myQuestions = /*#-editable-code*/["Where are you from?"]/*#-end-editable-code*/
let myAnswers = /*#-editable-code*/["United States. 🇺🇸", "USA. 😁"]/*#-end-editable-code*/

addQuestion(botName: /*#-editable-code*/"MyBot"/*#-end-editable-code*/, questions: myQuestions, answers: myAnswers)
//#-hidden-code
saveUserInput(input: myQuestions)
//#-end-hidden-code

