/*:
 
 ![Create Image](Create.png)
 
 # Create a Chatbot

Now we come to the most enjoy part. In this page, you can create your own chatbot. 🤘
 
To create a chatbot, we use a function called addNewBot. addNewBot have three parameters: name, avatarEmoji, avatarColor. Write name of chatbot to name. And type an emoji to avatar, which creates chatbot's profile photo. Finally, choose a color that will be the background for the chatbot's profile photo. 
 
Change the code snippet at the end of page to whatever you want, and run code.
 
And then, scroll the end of view, you see a chatbot you created. Click the chatbot which you created.
*/
//#-hidden-code
setView(page: 3)
saveUserInput(input: DataSource.newBotID)
//#-end-hidden-code
addNewBot(name: /*#-editable-code*/"MyBot"/*#-end-editable-code*/, avatarEmoji: /*#-editable-code*/"🤖"/*#-end-editable-code*/, avatarColor: /*#-editable-code*/#colorLiteral(red: 0.0862745098, green: 0.6274509804, blue: 0.5215686275, alpha: 1) /*#-end-editable-code*/)
