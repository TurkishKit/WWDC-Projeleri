import Foundation

public func filepath(filename: String) -> Data {
    let filePath: String! = Bundle.main.path(forResource: filename, ofType: "json")
    let JSONPath = try! String(contentsOfFile: filePath).data(using: .utf8)!
    return JSONPath
}
