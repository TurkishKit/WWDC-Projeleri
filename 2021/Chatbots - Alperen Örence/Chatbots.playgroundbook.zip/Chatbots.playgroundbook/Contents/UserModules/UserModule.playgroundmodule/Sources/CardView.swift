import SwiftUI

public struct CardView: View {
    var viewedBot: Int
    @Binding var selectedBot: Int?
    @Binding var isCalledOnFirstPage: Bool
    @Binding var showBotSelection: Bool
    @Binding var showSettingsView: Bool
    @Binding var showChatView: Bool
    
    public init(selectedBot: Binding<Int?>, viewedBot: Int, isCalledOnFirstPage: Binding<Bool>, showBotSelection: Binding<Bool>, showSettingsView: Binding<Bool>, showChatView: Binding<Bool>) {
        self._selectedBot = selectedBot
        self.viewedBot = viewedBot
        self._isCalledOnFirstPage = isCalledOnFirstPage
        self._showBotSelection = showBotSelection
        self._showSettingsView = showSettingsView
        self._showChatView = showChatView
    }
    
    public var body: some View {
        Button(action: {
            self.selectedBot = self.viewedBot
            withAnimation() {
                self.showBotSelection.toggle()
                self.showChatView.toggle()
            }
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 35.0)
                    .foregroundColor(Color(hex: "#3498db"))
                    .frame(width: 250, height: 350)
                    .shadow(color: Color.white.opacity(0.15), radius: 10, x: 5.0, y: 5.0)
                VStack {
                    ProfilePhotoView(selectedBot: self.viewedBot, size: 100)
                        .overlay(
                            Circle()
                                .stroke(lineWidth: 1.5)
                                .foregroundColor(Color(hex: "#34495e"))
                        )
                        .shadow(color: Color.white.opacity(0.15), radius: 10, x: 5.0, y: 5.0)
                    Text(DataSource.botDetails[viewedBot].name)
                        .font(.largeTitle)
                        .fontWeight(.medium)
                        .padding(.bottom)
                        .foregroundColor(.white)
                    HStack {
                        Button(action: {
                            self.selectedBot = self.viewedBot
                            withAnimation() {
                                self.showBotSelection.toggle()
                                self.showChatView.toggle()
                            }
                        }) {
                        Image(systemName: "message")
                            .padding(.horizontal, 20.0)
                            .font(.largeTitle)
                            .foregroundColor(.white)
                        }
                        Button(action: {
                            self.selectedBot = self.viewedBot
                            self.isCalledOnFirstPage = true
                            withAnimation() {
                                self.showBotSelection.toggle()
                                self.showSettingsView.toggle()
                            }
                        }) {
                        Image(systemName: "gearshape")
                            .padding(.horizontal, 20.0)
                            .font(.largeTitle)
                            .foregroundColor(.white)
                        }
                    }
                    .padding(.top)
                }
            }
        }
    }
}
