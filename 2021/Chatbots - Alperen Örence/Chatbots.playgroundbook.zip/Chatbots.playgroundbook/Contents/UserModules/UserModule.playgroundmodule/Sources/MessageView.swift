import SwiftUI

public struct MessageView : View {
    var currentMessage: Message
    var selectedBot: Int
    
    public init(currentMessage: Message, selectedBot: Int) {
        self.currentMessage = currentMessage
        self.selectedBot = selectedBot
    }
    
    public var body: some View {
        HStack(alignment: .bottom, spacing: 15) {
            if currentMessage.isBot {
                ProfilePhotoView(selectedBot: self.selectedBot, size: 40)
            } else {
                Spacer()
            }
            ContentMessageView(contentMessage: currentMessage.content, isBot: currentMessage.isBot)
            if !currentMessage.isBot == false {
                Spacer()
            }
        }
        .padding()
    }
}
