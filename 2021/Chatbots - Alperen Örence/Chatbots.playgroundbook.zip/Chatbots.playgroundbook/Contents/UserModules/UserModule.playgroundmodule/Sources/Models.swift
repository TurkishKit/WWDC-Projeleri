public struct ChatBotDetails: Codable, Hashable {
    var ID: Int
    var name: String
    var avatar: String
    var color: String
    var isAvailable: Bool = true
}

public struct Questions: Codable, Hashable {
    var questions: [String]
    var answers: [String]
}

public struct Message: Decodable, Hashable {
    var content: String
    var isBot: Bool
}

public struct AlertModel: Equatable {
    var ID: Int
    var page: [Int]
    var message: String
    var isPass: Bool
}

public class UserInputs {
    public var userQuestion: [String] = []
    public var userBotID: Int = Int()
    static let shared = UserInputs()
    public init() {}
}
