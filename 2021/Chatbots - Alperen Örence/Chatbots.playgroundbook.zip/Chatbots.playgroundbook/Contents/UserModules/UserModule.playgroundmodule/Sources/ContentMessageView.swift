import SwiftUI

public struct ContentMessageView: View {
    var contentMessage: String
    var isBot: Bool
    public init(contentMessage: String, isBot: Bool) {
        self.contentMessage = contentMessage
        self.isBot = isBot
    }
    public var body: some View {
        Text(contentMessage)
            .padding(10)
            .foregroundColor(isBot ? Color.white : Color.black)
            .background(isBot ? Color(hex: "#2d98da") : Color(UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1.0)))
            .cornerRadius(10)
    }
}
