import Foundation

public var currentPage = 0

public var PlaygroundMessages: [AlertModel] = [
    AlertModel(ID: 0, page: [0], message: "You completed first page! \nYou can continue to chat or go to next page. 😎\n\n[**Next Page**](@next)", isPass: true),
    AlertModel(ID: 1, page: [1], message: "Wow, you did it! In next page, you can add new questions to chatbots. 🥳\n\n[**Next Page**](@next)", isPass: true),
    AlertModel(ID: 2, page: [2], message: "You finished this chapter! In next chapter, you can create your own chatbot. 🤩\n\n[**Next Page**](@next)", isPass: true),
    AlertModel(ID: 3, page: [3], message: "You successfully added your chatbot! Chatbot doesn't know any questions, because you don't do it. In next page, you can add your questions to your chatbot. 🎉\n\n[**Next Page**](@next)", isPass: true),
    AlertModel(ID: 4, page: [4], message: "Wow, that's amazing! You created a chatbot and added your questions. You learned so many things. It's time to show your skills. 🚀\n\n[**Next Page**](@next)", isPass: true),
    AlertModel(ID: 5, page: [5], message: "Congratulations! You finished playground. 🎉", isPass: true),
    AlertModel(ID: 6, page: [0, 1, 2, 4], message: "Hmm, chatbot doesn't know this question. Try to ask 'Tell me a joke.' or 'Which technologies announced in WWDC20?'.", isPass: false)
]

public struct DataSource: Encodable {
    static public var botDetails: [ChatBotDetails] = try! JSONDecoder().decode([ChatBotDetails].self, from: filepath(filename: "ChatBots"))
    static public var questionsAll = try! JSONDecoder().decode([Int : [Questions]].self, from: filepath(filename: "Questions"))
    static public var messagesAll : [Int : [Message]]! = [:]
    static public var firstQuestion = "Hi, how can I help you?"
    static public var newBotID = botDetails.last!.ID + 1
    static public var emptyQuestion: [Questions] = questionsAll[0]!
    static public var newName = 1
    public init() {}
}
