import PlaygroundSupport

public func alert(ID: [Int]) {
    var pageAlert: [AlertModel] = []
    let helper: ChatHelper = ChatHelper.shared
    
    for i in PlaygroundMessages {
        for ii in ID {
            if i.ID == ii {
                pageAlert.append(i)
            }
        }
    }
    
    for i in pageAlert {
        if !i.page.contains(currentPage) {
            let index = pageAlert.firstIndex(of: i)!
            pageAlert.remove(at: index)
        }
    }
    
    for i in pageAlert {
        if i.isPass {
            PlaygroundPage.current.assessmentStatus = .pass(message: i.message)
            helper.successMessageSent.toggle()
        } else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: [i.message], solution: nil)
        }
    }
    
}
