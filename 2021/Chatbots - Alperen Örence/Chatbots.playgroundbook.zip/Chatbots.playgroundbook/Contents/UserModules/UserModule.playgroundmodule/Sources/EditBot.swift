import UIKit
import PlaygroundSupport

public func editBot(oldName: String, newName: String, avatarEmoji: String, avatarColor: UIColor) {
    var name = newName
    var emoji = avatarEmoji
    var color = avatarColor.convertToHex()
    var isFound = false
    
    if name == "" || name == " " || name == "  " {
        name = "ChatBot " + String(DataSource.newName)
        DataSource.newName += 1
        print("")
    }
    

    let isEmojiContains = emoji.unicodeScalars.contains(where: {
        $0.properties.isEmoji
    })
    
    if isEmojiContains {
        findEmoji: for i in emoji {
            if i.unicodeScalars.contains(where: { $0.properties.isEmoji }) {
                emoji = String(i)
                break findEmoji
            }
        }
    } else {
        print("please type an emoji")
        emoji = "🤖"
    }


    
    findID: for i in DataSource.botDetails {
        if i.name == oldName {
            DataSource.botDetails[i.ID] = ChatBotDetails(ID: i.ID, name: name, avatar: emoji, color: color)
            isFound.toggle()
            break findID
        }
    }
    
    if !isFound {
        DataSource.botDetails[0] = ChatBotDetails(ID: 0, name: name, avatar: emoji, color: color)
        isFound.toggle()
    }
    
    save()
}
