import SwiftUI
import UIKit

public struct SettingsView: View {
    @Binding var selectedBot: Int?
    @State var selectedBotDetails: ChatBotDetails
    @Binding var isNewBot: Bool
    @Binding var showBotSelection: Bool
    @Binding var showSettingsView: Bool
    @Binding var showChatView: Bool
    @Binding var isCalledOnFirstPage: Bool
    
    public init(selectedBot: Int?, isCalledOnFirstPage: Binding<Bool>, showBotSelection: Binding<Bool>, showSettingsView: Binding<Bool>, showChatView: Binding<Bool>) {
        if selectedBot == nil {
            self._selectedBotDetails = State(initialValue: ChatBotDetails(ID: Int(), name: String(), avatar: String(), color: String()))
            self._isNewBot = Binding.constant(true)
            self._selectedBot = Binding.constant(DataSource.newBotID)
        } else {
            self._selectedBot = Binding.constant(selectedBot)
            self._selectedBotDetails = State(initialValue: DataSource.botDetails[selectedBot!])
            self._isNewBot = Binding.constant(false)
        }
        self._isCalledOnFirstPage = isCalledOnFirstPage
        self._showBotSelection = showBotSelection
        self._showSettingsView = showSettingsView
        self._showChatView = showChatView
    }
    
    public var body: some View {
        VStack {
            HStack {
                Button(action: {
                    if isCalledOnFirstPage {
                        withAnimation() {
                            self.showSettingsView.toggle()
                            self.showBotSelection.toggle()
                        }
                    } else {
                        withAnimation() {
                            self.showSettingsView.toggle()
                            self.showChatView.toggle()
                        }
                    }
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 27.5))
                        .foregroundColor(Color(hex: "#2d98da"))
                    Text("Back")
                        .foregroundColor(Color(hex: "#2d98da"))
                }
                .padding()
                
                Spacer()
                
                
            }
            if isNewBot == false {
                ProfilePhotoView(selectedBot: self.selectedBot!, size: 100)
                Text(selectedBotDetails.name + " Settings")
                    .font(.largeTitle)
                    .fontWeight(.medium)
                    .foregroundColor(.white)
            } else {
                Text("Add New Bot")
                    .font(.largeTitle)
                    .fontWeight(.medium)
                    .foregroundColor(.white)
            }
            ScrollView(showsIndicators: false) {
                VStack {
                    SettingsElement(selectedBotDetails: self.$selectedBotDetails, elementName: "Name", fieldPlaceholder: "Bot Name", data: $selectedBotDetails.name)
                        .padding(.top, 2.0)
                    SettingsElement(selectedBotDetails: self.$selectedBotDetails, elementName: "Avatar", fieldPlaceholder: "Bot Avatar", data: $selectedBotDetails.avatar)
                    SettingsElement(selectedBotDetails: self.$selectedBotDetails, elementName: "Color", fieldPlaceholder: "Hex Color Code (6-digit)", data:  $selectedBotDetails.color)
                    HStack {
                        if selectedBot != 0 && isNewBot == false {
                            Button(action: {
                                DataSource.botDetails[selectedBot!].isAvailable.toggle()
                                withAnimation() {
                                    self.showSettingsView.toggle()
                                    self.showBotSelection.toggle()
                                }
                            }) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundColor(Color(hex: "#e74c3c"))
                                        .padding()
                                        .frame(width: 125, height: 75, alignment: .center)
                                    Text("Delete")
                                        .foregroundColor(.white)
                                        .padding()
                                }
                            }
                        }
                        Button(action: {
                            if isNewBot {
                                let newBot = DataSource.newBotID
                                addNewBot(name: selectedBotDetails.name, avatarEmoji: selectedBotDetails.avatar, avatarColor: UIColor(hex: selectedBotDetails.color))
                                DataSource.questionsAll[newBot] = DataSource.emptyQuestion
                            } else {
                                let oldName = DataSource.botDetails[self.selectedBot!].name
                                editBot(oldName: oldName, newName: selectedBotDetails.name, avatarEmoji: selectedBotDetails.avatar, avatarColor: UIColor(hex: selectedBotDetails.color))
                            }
                            
                            if isCalledOnFirstPage {
                                withAnimation() {
                                    self.showSettingsView.toggle()
                                    self.showBotSelection.toggle()
                                }
                            } else {
                                withAnimation() {
                                    self.showSettingsView.toggle()
                                    self.showChatView.toggle()
                                }
                            }
                        }) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundColor(Color(hex: "#2d98da"))
                                    .padding()
                                    .frame(width: 125, height: 75, alignment: .center)
                                Text("Save")
                                    .foregroundColor(.white)
                            }
                        }
                    }
                }
            }
        }
    }
}
