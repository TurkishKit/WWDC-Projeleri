import UIKit

public func addNewBot(name: String, avatarEmoji: String, avatarColor: UIColor) {
    var name = name
    var emoji = avatarEmoji
    var color = avatarColor.convertToHex()
    var existingNames: [String] = []
    
    if name == "" || name == " " || name == "  " {
        name = "ChatBot " + String(DataSource.newName)
        DataSource.newName += 1
    }
    
    for i in DataSource.botDetails {
        existingNames.append(i.name)
    }
    
    for i in existingNames {
        if name == i {
            name += " 1"
        }
    }
    
    let isEmojiContains = emoji.unicodeScalars.contains(where: {
        $0.properties.isEmoji
    })
    
    if isEmojiContains {
        findEmoji: for i in emoji {
            if i.unicodeScalars.contains(where: { $0.properties.isEmoji }) {
                emoji = String(i)
                break findEmoji
            }
        }
    } else {
        emoji = "🤖"
    }
    
    DataSource.botDetails.append(ChatBotDetails(ID: DataSource.newBotID, name: name, avatar: emoji, color: color))
    ChatHelper.shared.realTimeMessages!.updateValue([Message(content: DataSource.firstQuestion, isBot: true)], forKey: DataSource.newBotID)
    DataSource.questionsAll[DataSource.newBotID] = []
    DataSource.newBotID += 1
    save()
}
