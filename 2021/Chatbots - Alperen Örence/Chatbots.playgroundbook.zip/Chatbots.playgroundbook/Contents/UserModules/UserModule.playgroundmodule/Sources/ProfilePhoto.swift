import SwiftUI

public struct ProfilePhotoView: View {
    var size: Int
    var selectedBot: Int
    @State var selectedBotDetails: ChatBotDetails
    
    public init(selectedBot: Int, size: Int) {
        self.size = size
        let available = DataSource.botDetails.indices.contains(selectedBot)
        if available {
            self.selectedBot = selectedBot
        } else {
            self.selectedBot = 0
        }
        self._selectedBotDetails = State(initialValue: DataSource.botDetails[self.selectedBot])
        
    }
    
    public var body: some View {
        ZStack {
            Rectangle()
                .frame(width: CGFloat(size), height: CGFloat(size))
                .foregroundColor(Color(hex: selectedBotDetails.color))
                .cornerRadius(60.0)
            Text(selectedBotDetails.avatar)
                .font(.system(size:  CGFloat(size * 1/2)))
        }
    }
}

