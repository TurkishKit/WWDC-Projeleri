public func addQuestion(botName: String, questions: [String], answers: [String]) {
    var slugQuestions: [String] = []
    
    for i in questions {
        slugQuestions.append(i.convertedToSlug()!)
    }
    
    findID: for i in DataSource.botDetails {
        if i.name == botName {
            DataSource.questionsAll[i.ID]?.append(Questions(questions: slugQuestions, answers: answers))
            break findID
        }
    }
    
    save()
}
