import SwiftUI

public struct SettingsElement : View {
    var elementName: String = String()
    var fieldPlaceholder: String = String()
    var data: Binding<String>
    var isColorView: Bool
    @Binding var selectedBotDetails: ChatBotDetails
    
    public init(selectedBotDetails: Binding<ChatBotDetails>, elementName: String, fieldPlaceholder: String, data: Binding<String>) {
        self.elementName = elementName
        self.fieldPlaceholder = fieldPlaceholder
        self.data = data
        self.isColorView = false
        _selectedBotDetails = selectedBotDetails
    }
    
    public var body: some View {
        HStack {
            Text(elementName + ":")
                .foregroundColor(.white)
            Spacer()
                TextField(fieldPlaceholder, text: data)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
        }
        .padding(.horizontal)
        .padding(.vertical, 5.0)
    }
}
