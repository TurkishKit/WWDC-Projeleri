import SwiftUI

public struct FirstPage: View {
    @Binding var selectedBot: Int?
    @Binding var isCalledOnFirstPage: Bool
    @Binding var showBotSelection: Bool
    @Binding var showSettingsView: Bool
    @Binding var showChatView: Bool
    
    public init(selectedBot: Binding<Int?>, isCalledOnFirstPage: Binding<Bool>, showBotSelection: Binding<Bool>, showSettingsView: Binding<Bool>, showChatView: Binding<Bool>) {
        self._selectedBot = selectedBot
        self._isCalledOnFirstPage = isCalledOnFirstPage
        self._showBotSelection = showBotSelection
        self._showSettingsView = showSettingsView
        self._showChatView = showChatView
    }
    
    public var body: some View {
        VStack {
            Text("Chatbots")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(Color.white)
                .padding()
            ScrollView(showsIndicators: false) {
                VStack() {
                    ForEach(0..<DataSource.botDetails.count) { i in
                        let available = DataSource.botDetails[i].isAvailable
                        if available {
                            CardView(selectedBot: self.$selectedBot, viewedBot: i, isCalledOnFirstPage: self.$isCalledOnFirstPage, showBotSelection: self.$showBotSelection, showSettingsView: self.$showSettingsView, showChatView: self.$showChatView)
                                .padding()
                        }
                    }
                    AddView(selectedBot: self.$selectedBot, isCalledOnFirstPage: self.$isCalledOnFirstPage, showBotSelection: self.$showBotSelection, showSettingsView: self.$showSettingsView, showChatView: self.$showChatView)
                        .padding()
                }
                .padding()
            }
            Spacer()
        }
    }
}



