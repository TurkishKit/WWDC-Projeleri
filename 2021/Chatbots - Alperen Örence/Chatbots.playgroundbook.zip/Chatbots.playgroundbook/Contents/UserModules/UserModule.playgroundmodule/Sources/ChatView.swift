import SwiftUI
import PlaygroundSupport

public struct ChatView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @State var active = false
    @State var typingMessage: String = ""
    @ObservedObject var chatHelper: ChatHelper = .shared
    var selectedBot: Int = 0
    public var questions: [Questions]!
    
    @Binding var isCalledOnFirstPage: Bool
    @Binding var showBotSelection: Bool
    @Binding var showSettingsView: Bool
    @Binding var showChatView: Bool
    
    public init(selectedBot: Int, isCalledOnFirstPage: Binding<Bool>, showBotSelection: Binding<Bool>, showSettingsView: Binding<Bool>, showChatView: Binding<Bool>) {
        self.selectedBot = selectedBot
        self.questions = DataSource.questionsAll[selectedBot]
        self._isCalledOnFirstPage = isCalledOnFirstPage
        self._showBotSelection = showBotSelection
        self._showSettingsView = showSettingsView
        self._showChatView = showChatView
        
        if currentPage == 3 {
            if let keyValue = PlaygroundKeyValueStore.current["UserBot"],
               case .integer(let value) = keyValue {
                if selectedBot == value {
                    UserModule.alert(ID: [3])
                }
            }
        }
    }
    
    public var body: some View {
        VStack {
            NavigationBar(selectedBot: self.selectedBot, isCalledOnFirstPage: self.$isCalledOnFirstPage, showBotSelection: self.$showBotSelection, showSettingsView: self.$showSettingsView, showChatView: self.$showChatView)
                .padding(.top, 0.0)
            ScrollView(showsIndicators: false) {
                VStack() {
                    ForEach(self.chatHelper.realTimeMessages![self.selectedBot]!, id: \.self) { i in
                        MessageView(currentMessage: i, selectedBot: self.selectedBot)
                    }
                }
            }
            .frame(alignment: .top)
            HStack {
                TextField("Message...", text: $typingMessage)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button(action: {
                    if typingMessage != "" {
                        chatHelper.sendMessage(message: typingMessage, selectedBot: selectedBot)
                        typingMessage = ""
                    }
                }) {
                    Image(systemName: "paperplane")
                        .font(.system(size: 25))
                        .foregroundColor(Color(hex: "#2d98da"))
                }
            }
            .frame(minHeight: CGFloat(50)).padding()
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}



