import SwiftUI

public struct AddView: View {
    
    @Binding var selectedBot: Int?
    @Binding var isCalledOnFirstPage: Bool
    @Binding var showBotSelection: Bool
    @Binding var showSettingsView: Bool
    @Binding var showChatView: Bool
    
    public init(selectedBot: Binding<Int?>, isCalledOnFirstPage: Binding<Bool>, showBotSelection: Binding<Bool>, showSettingsView: Binding<Bool>, showChatView: Binding<Bool>) {
        self._isCalledOnFirstPage = isCalledOnFirstPage
        self._showBotSelection = showBotSelection
        self._showSettingsView = showSettingsView
        self._showChatView = showChatView
        self._selectedBot = selectedBot
    }
    
    public var body: some View {
        Button(action: {
            self.selectedBot = nil
            self.isCalledOnFirstPage = true
            withAnimation() {
                self.showBotSelection.toggle()
                self.showSettingsView.toggle()
            }
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 35.0)
                    .foregroundColor(Color(hex: "#3498db"))
                    .frame(width: 250, height: 350)
                    .shadow(color: Color.white.opacity(0.15), radius: 10, x: 5.0, y: 5.0)
                VStack {
                    Image(systemName: "plus")
                        .padding(.horizontal, 20.0)
                        .font(.system(size: 75))
                        .foregroundColor(.white)
                        .padding()
                    Text("Add")
                        .font(.largeTitle)
                        .fontWeight(.medium)
                        .padding(.bottom)
                        .foregroundColor(.white)
                }
            }
        }
    }
}
