public func setMessages() {
    let helper = ChatHelper.shared
    for i in DataSource.botDetails {
       // helper.realTimeMessages!.updateValue([Message(content: DataSource.firstQuestion, isBot: true)], forKey: i)
        helper.realTimeMessages![i.ID] = []
        helper.addMessage(Message(content: DataSource.firstQuestion, isBot: true), selectedBot: i.ID)
    }
}
