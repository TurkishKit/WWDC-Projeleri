import Foundation
import PlaygroundSupport

public func save() {
    let encoder = JSONEncoder()
    encoder.outputFormatting = .prettyPrinted
    let botDetails = try! encoder.encode(DataSource.botDetails)
    let questionsAll = try! encoder.encode(DataSource.questionsAll)
    
    PlaygroundKeyValueStore.current["botDetails"] = .data(botDetails)
    PlaygroundKeyValueStore.current["questionsAll"] = .data(questionsAll)
    
    PlaygroundKeyValueStore.current["newBotID"] = .integer(DataSource.newBotID)
    PlaygroundKeyValueStore.current["newName"] = .integer(DataSource.newName)
    //PlaygroundKeyValueStore.current["isSaved"] = .boolean(true)
}

public func pull() {
        if let keyValue = PlaygroundKeyValueStore.current["botDetails"],
           case .data(let value) = keyValue {
            DataSource.botDetails = try! JSONDecoder().decode([ChatBotDetails].self, from: value)
            ChatHelper.shared.addMessage(Message(content: "pull run", isBot: true), selectedBot: 0)
        }
        
        if let keyValue = PlaygroundKeyValueStore.current["questionsAll"],
           case .data(let value) = keyValue {
            DataSource.questionsAll = try! JSONDecoder().decode([Int: [Questions]].self, from: value)
        }
        
        if let keyValue = PlaygroundKeyValueStore.current["newBotID"],
           case .integer(let value) = keyValue {
            DataSource.newBotID = value
        }
        
        
        if let keyValue = PlaygroundKeyValueStore.current["newName"],
           case .integer(let value) = keyValue {
            DataSource.newName = value
        }
    
}

public func saveUserInput(input: Any) {
    let encoder = JSONEncoder()
    encoder.outputFormatting = .prettyPrinted
    
    if type(of: input) == Int.self {
        let userInput = input as! Int
        PlaygroundKeyValueStore.current["UserBot"] = .integer(userInput)
    } else {
        guard let dataInput: [String] = input as? [String] else { return }
        let data = try! encoder.encode(dataInput)
        PlaygroundKeyValueStore.current["UserInput"] = .data(data)
    }
}
