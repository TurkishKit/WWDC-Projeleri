import Combine
import PlaygroundSupport
import Foundation

public class ChatHelper: ObservableObject {
    var didChange = PassthroughSubject<Void, Never>()
    @Published var realTimeMessages = DataSource.messagesAll
    @Published var response = false
    @Published var successMessageSent = false
    @Published var slugMessage: String? = nil
    static let shared = ChatHelper()
    public init() {}
    
    func addMessage(_ chatMessage: Message, selectedBot: Int) {
        realTimeMessages![selectedBot]?.append(chatMessage)
        didChange.send(())
    }
    
    func sendMessage(message: String, selectedBot: Int) {
        let helper: ChatHelper = ChatHelper.shared
        
        if message != "" {
            helper.addMessage(Message(content: message, isBot: false), selectedBot: selectedBot)
            if let slugifyMessage = message.convertedToSlug() {
                helper.slugMessage = slugifyMessage
        //        helper.response.toggle()
                helper.generateResponse(selectedBot: selectedBot)
                if currentPage == 2 || currentPage == 4 {
                    
                    if let keyValue = PlaygroundKeyValueStore.current["UserInput"],
                       case .data(let value) = keyValue {
                        let mainValue = try! JSONDecoder().decode([String].self, from: value)
                        findUserQuestion: for i in mainValue {
                            if slugifyMessage == i.convertedToSlug() {
                                alert(ID: [2, 4])
                                break findUserQuestion
                            }
                        }
                    }
                    
                }
            } else {
                helper.addMessage(Message(content: "I don't understand. Please ask a question.", isBot: true), selectedBot: selectedBot)
                if !helper.successMessageSent {
                    alert(ID: [6])
                }
            }
        }
    }
    
    func generateResponse(selectedBot: Int) {
        let helper: ChatHelper = ChatHelper.shared
        var answer = "I don't know this question, sorry. Please ask an another question."
        let questions: [Questions]! = DataSource.questionsAll[selectedBot]
        var isChanged = false
        findAnswer: for i in questions {
            for ii in i.questions {
                if ii == helper.slugMessage {
                    answer = i.answers.randomElement()!
                    isChanged = true
                    if !helper.successMessageSent {
                        alert(ID: [0])
                    }
                    break findAnswer
                }
            }
        }
        
        if !isChanged && !helper.successMessageSent {
            alert(ID: [6])
        }
        
        if answer != "" {
            helper.addMessage(Message(content: answer, isBot: true), selectedBot: selectedBot)
        //    helper.response.toggle()
            helper.slugMessage = nil
        }
    }
}
