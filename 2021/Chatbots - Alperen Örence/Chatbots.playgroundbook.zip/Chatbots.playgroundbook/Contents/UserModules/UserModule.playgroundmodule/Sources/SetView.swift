import SwiftUI
import BookCore
import PlaygroundSupport
import Combine

public func setView(page: Int) {
    currentPage = page
    pull()
    setMessages()
    let view = MainView().environmentObject(ChatHelper.shared)
    PlaygroundPage.current.setLiveView(view)
    alert(ID: [1, 5])
}
