//
//  SwiftUIView.swift
//  ChatBot
//
//  Created by Alperen Örence
//

import SwiftUI
import Combine

public struct MainView: View {
    @State var showBotSelection = false
    @State var showChatView = false
    @State var showSettingsView = false
    @State var selectedBot: Int?
    @State var isCalledOnFirstPage = false
    
    public init() {}
    public var body: some View {
        ZStack {
            Color(hex: "#2c3e50")
                .onAppear {
                    withAnimation {
                        self.showBotSelection = true
                    }
                }
            
            VStack {
                if showChatView {
                    ChatView(selectedBot: self.selectedBot!, isCalledOnFirstPage: self.$isCalledOnFirstPage, showBotSelection: self.$showBotSelection, showSettingsView: self.$showSettingsView, showChatView: self.$showChatView)
                        .transition(AnyTransition.opacity)
                        .environmentObject(ChatHelper.shared)
                }
                if showSettingsView {
                    if isCalledOnFirstPage {
                        SettingsView(selectedBot: self.selectedBot, isCalledOnFirstPage: self.$isCalledOnFirstPage, showBotSelection: self.$showBotSelection, showSettingsView: self.$showSettingsView, showChatView: self.$showChatView)
                            .transition(AnyTransition.opacity)
                    } else {
                        SettingsView(selectedBot: self.selectedBot, isCalledOnFirstPage: self.$isCalledOnFirstPage, showBotSelection: self.$showBotSelection, showSettingsView: self.$showSettingsView, showChatView: self.$showChatView)
                            .transition(AnyTransition.slide.combined(with: AnyTransition.opacity))
                    }
                }
                if showBotSelection {
                    FirstPage(selectedBot: self.$selectedBot, isCalledOnFirstPage: self.$isCalledOnFirstPage, showBotSelection: self.$showBotSelection, showSettingsView: self.$showSettingsView, showChatView: self.$showChatView)
                        .padding(.all, 30.0)
                        .transition(AnyTransition.slide.combined(with: AnyTransition.opacity))
                        .zIndex(1)
                        .animation(.default)
                        Spacer()
                }
            }
        }
    }
}


