import SwiftUI

public struct NavigationBar: View {
    
    @Binding var showBotSelection: Bool
    @Binding var showSettingsView: Bool
    @Binding var showChatView: Bool
    @Binding var isCalledOnFirstPage: Bool
    var selectedBot: Int = 0
    @State var selectedBotDetails: ChatBotDetails
    
    public init(selectedBot: Int, isCalledOnFirstPage: Binding<Bool>, showBotSelection: Binding<Bool>, showSettingsView: Binding<Bool>, showChatView: Binding<Bool>) {
        self.selectedBot = selectedBot
        self._selectedBotDetails = State(initialValue: DataSource.botDetails[selectedBot])
        self._isCalledOnFirstPage = isCalledOnFirstPage
        self._showBotSelection = showBotSelection
        self._showSettingsView = showSettingsView
        self._showChatView = showChatView
    }
    
    public var body: some View {
        VStack {
            HStack {
                Button(action: {
                    withAnimation() {
                        self.showBotSelection.toggle()
                        self.showChatView.toggle()
                    }
                }) {
                    HStack {
                        Image(systemName: "list.bullet")
                            .padding(.leading, 20.0)
                            .font(.largeTitle)
                            .foregroundColor(Color(hex: "#2d98da"))
                    }
            }
                ProfilePhotoView(selectedBot: self.selectedBot, size: 50)
                    .frame(width: 40.0, height: 40.0)
                    .padding(.leading, 20.0)
                Text(selectedBotDetails.name)
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding(.leading, 5.0)
                Spacer()
                Button(action: {
                    self.isCalledOnFirstPage = false
                    withAnimation() {
                        self.showChatView.toggle()
                        self.showSettingsView.toggle()
                    }
                }) {
                    Image(systemName: "gearshape")
                        .padding(.horizontal, 20.0)
                        .font(.largeTitle)
                        .foregroundColor(Color(hex: "#2d98da"))
                }
            }
            .padding([.vertical, .top])
            Divider()
        }
    }
}
